<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>404 - Page Not Found</title>
    <link rel="stylesheet" href="main.css">
    <style>
        body { text-align: center; padding: 60px; font-family: 'Nunito', Arial, sans-serif; background: #fafafa; color: #23272b; }
        h1 { font-size: 3em; color: #97c933; margin-bottom: 0.5em; }
        p { font-size: 1.3em; margin-bottom: 2em; }
        a { color: #fff; background: #97c933; padding: 0.7em 2em; border-radius: 8px; text-decoration: none; font-weight: bold; transition: background 0.2s; }
        a:hover { background: #7fae28; }
        .error-img { max-width: 300px; margin-bottom: 2em; }
    </style>
</head>
<body>
    <img src="https://cdn-icons-png.flaticon.com/512/2748/2748558.png" alt="404 Not Found" class="error-img">
    <h1>404 - Page Not Found</h1>
    <p>Sorry, the page you are looking for does not exist or has been moved.</p>
    <a href="index.php">Go to Home</a>
</body>
</html> 