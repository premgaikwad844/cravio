<?php
$host = 'sql109.infinityfree.com';
$user = 'if0_39329540';
$pass = 'Prem28831924'; // Replace with your actual password
$db = 'if0_39329540_login12';

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}
?> 