<?php
session_start();
require 'db_connect.php';
if (isset($_SESSION['login_history_id'])) {
    $history_id = $_SESSION['login_history_id'];
    $sql = "UPDATE user_login_history SET logout_time = NOW() WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $history_id);
    mysqli_stmt_execute($stmt);
}
session_unset();
session_destroy();
header("Location: index3.php");
exit(); 