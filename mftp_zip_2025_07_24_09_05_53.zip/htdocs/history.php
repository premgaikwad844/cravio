<?php
require 'db_connect.php';
$sql = "SELECT username, login_time, logout_time FROM user_login_history ORDER BY login_time DESC";
$result = mysqli_query($conn, $sql);
echo "<table border='1' style='margin:2rem auto; border-collapse:collapse; min-width:400px;'>";
echo "<tr><th>Username</th><th>Login Time</th><th>Logout Time</th></tr>";
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
        <td>" . htmlspecialchars($row['username']) . "</td>
        <td>" . htmlspecialchars($row['login_time']) . "</td>
        <td>" . htmlspecialchars($row['logout_time']) . "</td>
    </tr>";
}
echo "</table>";
?> 