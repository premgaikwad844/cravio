<?php
$servername = "sql109.infinityfree.com";
$username = "if0_39329540";
$password = "Prem28831924";
$dbname = "if0_39329540_login_db12";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | fitmeal</title>
    <link rel="stylesheet" href="main.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:700,600,400&display=swap" rel="stylesheet">
</head>
<body>
<!-- Mobile-Only Menubar Start -->
<style>
@media (max-width: 768px) {
  .cravio-mobile-menubar, .cravio-mobile-hamburger {
    display: block;
  }
  .cravio-mobile-menubar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background: #fff;
    z-index: 2000;
    box-shadow: 0 4px 16px rgba(0,0,0,0.08);
    padding: 24px 0 12px 0;
    display: none;
  }
  .cravio-mobile-menubar.active {
    display: block;
  }
  .cravio-mobile-menubar ul {
    list-style: none;
    padding: 0;
    margin: 0 0 16px 0;
    text-align: center;
  }
  .cravio-mobile-menubar ul li {
    margin: 12px 0;
  }
  .cravio-mobile-menubar a {
    text-decoration: none;
    color: #23272b;
    font-size: 1.1rem;
    font-weight: 600;
    padding: 8px 20px;
    border-radius: 20px;
    display: inline-block;
    transition: background 0.2s;
  }
  .cravio-mobile-menubar a.active,
  .cravio-mobile-menubar a:hover {
    background: #97c933;
    color: #fff;
  }
  .cravio-mobile-hamburger {
    position: fixed;
    top: 16px;
    right: 24px;
    width: 40px;
    height: 40px;
    background: none;
    border: none;
    z-index: 2100;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 6px;
  }
  .cravio-mobile-hamburger span {
    display: block;
    height: 4px;
    width: 100%;
    background: #23272b;
    border-radius: 2px;
    transition: 0.3s;
  }
}
@media (min-width: 769px) {
  .cravio-mobile-menubar, .cravio-mobile-hamburger {
    display: none !important;
  }
}
</style>
<button class="cravio-mobile-hamburger" aria-label="Open menu" onclick="cravioToggleMobileMenu()">
  <span></span>
  <span></span>
  <span></span>
</button>
<div class="cravio-mobile-menubar" id="cravioMobileMenu">
  <ul>
    <li><a href="main.php">Home</a></li>
    <li><a href="search.php">Products</a></li>
    <li><a href="about.php">About us</a></li>
    <li><a href="contact.php" class="active">Contact Us</a></li>
  </ul>
  <?php if (isset($_SESSION['user_id'])): ?>
      <a href="logout.php" class="navbar-btn" style="background: #e53935; color: #fff; border-radius: 20px; padding: 8px 20px; display: inline-block; font-weight: bold;">Logout</a>
  <?php endif; ?>
</div>
<script>
function cravioToggleMobileMenu() {
  var menu = document.getElementById('cravioMobileMenu');
  menu.classList.toggle('active');
}
document.addEventListener('click', function(event) {
  var menu = document.getElementById('cravioMobileMenu');
  var hamburger = document.querySelector('.cravio-mobile-hamburger');
  if (!menu.contains(event.target) && !hamburger.contains(event.target)) {
    menu.classList.remove('active');
  }
});
document.querySelectorAll('.cravio-mobile-menubar a').forEach(function(link) {
  link.addEventListener('click', function() {
    document.getElementById('cravioMobileMenu').classList.remove('active');
  });
});
</script>
<!-- Mobile-Only Menubar End -->
    <nav class="navbar" style="position: relative; z-index: 10;">
        <div class="navbar-logo-group">
            <img src="f2-removebg-preview.png" alt="fitmeal logo" class="navbar-logo-icon">
            <div class="navbar-logo-text">
                <span class="navbar-logo-title">fitmeal</span>
                <span class="navbar-logo-subtitle">food delivery</span>
            </div>
        </div>
        <ul class="navbar-links">
            <li><a href="main.php">Home <span class="arrow">&#8250;</span></a></li>
            <li><a href="search.php">Products <span class="arrow">&#8250;</span></a></li>
            <li><a href="about.php">About us <span class="arrow">&#8250;</span></a></li>
            <li><a href="contact.php" class="active">Contact Us <span class="arrow">&#8250;</span></a></li>
        </ul>
        <!-- Removed Get Menu button -->
    </nav>
    <!-- Hero/Banner Section -->
    <section class="hero-banner" style="position:relative; background:#888a8e; min-height:320px; display:flex; align-items:center; justify-content:center; flex-direction:column;">
        <img src="https://wallpaperaccess.com/full/3124535.jpg" alt="Contact Banner" style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover; opacity:1; z-index:1;">
        <div style="position:relative; z-index:2; text-align:center; width:100%;">
            <h1 style="font-size:3rem; color:#fff; font-weight:800; margin-bottom:0.5rem;">Contact Us</h1>
            <div class="breadcrumbs" style="font-size:1.1rem; color:#d0e17d; font-weight:700;">
                <a href="main.php" style="color:#d0e17d; text-decoration:none;">Home</a>
                <span style="color:#fff; margin:0 8px;">|</span>
                <span style="color:#fff;">Contact</span>
            </div>
        </div>
    </section>
    <main style="min-height: 80vh; background: #fafafa; padding: 0 0 60px 0;">
        <section style="max-width: 1000px; margin: 40px auto 0 auto; background: #f8f9fa; border-radius: 18px; box-shadow: 0 4px 24px rgba(151,201,51,0.07); padding: 48px 32px; display: flex; flex-wrap: wrap; gap: 40px; justify-content: space-between; align-items: center;">
  <div style="flex:1 1 320px; min-width:220px; max-width:48%; display:flex; flex-direction:column; align-items:flex-start; gap:18px;">
    <h3 style="color:#23272b; font-size:1.3rem; font-weight:700; margin-bottom:0.5em;">Our Location</h3>
    <div style="display:flex; align-items:center; gap:12px;">
      <span style="font-size: 1.5rem; color: #97c933;">📍</span>
      <span style="font-size:1.08rem; color:#23272b;"><b>Sangli, Maharashtra, India</b></span>
    </div>
  </div>
  <div style="flex:1 1 320px; min-width:220px; max-width:48%; display:flex; flex-direction:column; align-items:flex-start; gap:18px;">
    <h3 style="color:#23272b; font-size:1.3rem; font-weight:700; margin-bottom:0.5em;">Contact & Feedback</h3>
    <div style="display:flex; align-items:center; gap:12px;">
      <span style="font-size: 1.5rem; color: #97c933;">✉️</span>
      <span style="font-size:1.08rem; color:#23272b;"><b>Email:</b> <a href="mailto:cravioweb@gmail.com" style="color:#97c933; font-weight:700; text-decoration:underline;">cravioweb@gmail.com</a></span>
    </div>
    <p style="color:#555; font-size:1.08rem; margin:0;">We love hearing from food lovers, home cooks, and anyone interested in food! Share your views, suggestions, or even your favorite dishes. If you spot any bugs or have ideas for improvement, please let us know—your feedback helps us make this site better for everyone. We usually respond within 24-48 hours.</p>
  </div>
  <style>
    @media (max-width: 700px) {
      section[style*='max-width: 1000px'] { flex-direction: column !important; align-items: stretch !important; }
      section[style*='max-width: 1000px'] > div { max-width: 100% !important; }
    }
  </style>
</section>
        <!-- Google Map Embed -->
        <section style="max-width: 1000px; margin: 32px auto 0 auto; border-radius: 18px; overflow: hidden; box-shadow: 0 2px 12px rgba(151,201,51,0.04);">
            <iframe title="Google Map" aria-label="Google Map" src="https://www.google.com/maps?q=Sangli,+Maharashtra,+India&output=embed" width="100%" height="320" frameborder="0" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </section>
        <!-- FAQ Section -->
        <section style="max-width: 1000px; margin: 40px auto 0 auto; background: #fff; border-radius: 18px; box-shadow: 0 2px 12px rgba(151,201,51,0.04); padding: 36px 32px;">
            <h2 style="color: #97c933; font-size: 1.7rem; font-weight: 700; margin-bottom: 1.2em; text-align: center;">Frequently Asked Questions</h2>
            <div style="display: flex; flex-direction: column; gap: 18px;">
                <div><b>How do your food recommendations work?</b><br>We provide general food recommendations based on popular dishes, cuisines, and dietary categories. There are no personalized recommendations.</div>
                <div><b>Is this a food delivery service?</b><br>No, we only provide food recommendations and information, not delivery or ordering.</div>
                <div><b>Do you have a physical office?</b><br>No, we are an online-only platform focused on food discovery and recommendations.</div>
                <div><b>Can I search for vegetarian or vegan dishes?</b><br>Yes, you can browse and filter for vegetarian, vegan, and other dietary preferences in our recommendations.</div>
                <div><b>Can I get recommendations for local cuisines?</b><br>Yes, you can explore food recommendations based on different regions and local cuisines of India.</div>
                <div><b>How often are the food recommendations updated?</b><br>We update our food recommendations regularly to reflect new trends, seasonal dishes, and popular cuisines.</div>
            </div>
        </section>
    </main>
    <!-- Footer -->
    <footer class="footer" style="background:#23272b; color:#fff; padding:60px 0 30px 0; margin-top:60px;">
        <div class="footer-content" style="max-width:1400px; margin:0 auto; display:flex; flex-wrap:wrap; gap:40px; justify-content:space-between;">
            <div style="flex:1 1 220px; min-width:220px;">
                <img src="f1-removebg-preview.png" alt="fitmeal logo" style="width:120px; margin-bottom:18px;">
                <div style="font-size:2rem; font-weight:700; color:#fff; margin-bottom:0.5em;">Cravio</div>
                <p class="footer-desc" style="font-size: 0.98rem; color: #fff; margin-bottom: 1.2em; max-width: 340px;">Cravio is your trusted companion for discovering, comparing, and enjoying the best food and drinks. We bring you curated recommendations, local favorites, and a seamless experience to satisfy every craving.</p>
                <div class="footer-socials" style="display: flex; gap: 18px; margin-bottom: 1.2em;">
                    <img src="https://cdn-icons-png.flaticon.com/128/733/733547.png" alt="Facebook" style="width: 32px; height: 32px; display: inline-block;">
                    <img src="https://cdn-icons-png.flaticon.com/128/733/733558.png" alt="Instagram" style="width: 32px; height: 32px; display: inline-block;">
                </div>
            </div>
            <div style="flex:1 1 180px; min-width:180px;">
                <h3 style="color:#c6e265; font-size:1.3rem; margin-bottom:18px;">Explore</h3>
                <ul style="list-style:none; padding:0; color:#fff;">
                    <li><a href="main.php" style="color:#fff; text-decoration:none;">Home</a></li>
                    <li><a href="search.php" style="color:#fff; text-decoration:none;">Products</a></li>
                    <li><a href="about.php" style="color:#fff; text-decoration:none;">About Us</a></li>
                    <li><a href="contact.php" style="color:#fff; text-decoration:none;">Contact Us</a></li>
                    <li><a href="privacy_and_policy.php" style="color:#fff; text-decoration:none;">Privacy & Policy</a></li>
                    <li><a href="terms_and_conditions.php" style="color:#fff; text-decoration:none;">Terms & Conditions</a></li>
                </ul>
            </div>
            <div style="flex:1 1 220px; min-width:220px;">
                <h3 style="color:#c6e265; font-size:1.3rem; margin-bottom:18px;">Contact info</h3>
                <div style="color:#fff;">
                    <div class="footer-contact-item" style="margin-bottom:10px;"><span class="footer-contact-icon">📍</span> <span><b>Our location:</b><br>Sangli, Maharashtra, India</span></div>
                    <div class="footer-contact-item"><span class="footer-contact-icon">✉️</span> <span><b>Email:</b><br>cravioweb@gmail.com</span></div>
                </div>
            </div>
        </div>
        <div style="text-align:center; color:#fff; margin-top:40px; font-size:1rem;">
            &copy; 2024 Cravio. All rights reserved.
        </div>
    </footer>
    <button id="backToTopBtn" title="Go to top" class="back-to-top-btn" aria-label="Back to top">
        <img src="https://cdn-icons-png.flaticon.com/128/664/664866.png" alt="Up Arrow" style="width: 60%; height: 60%; display: block; margin: auto; transform: rotate(-90deg);" />
    </button>
    <script>
const backToTopBtn = document.getElementById('backToTopBtn');
window.addEventListener('scroll', function() {
    if (window.scrollY > 200) {
        backToTopBtn.style.display = 'block';
    } else {
        backToTopBtn.style.display = 'none';
    }
});
backToTopBtn.addEventListener('click', function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
</script>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');
    $message = htmlspecialchars($_POST['message'] ?? '');
    $to = 'cravioweb@gmail.com';
    $subject = "New Contact Message from $name";
    $body = "Name: $name\nEmail: $email\nMessage:\n$message";
    $headers = "From: no-reply@cravioweb.com\r\n";
    if (mail($to, $subject, $body, $headers)) {
        echo '<script>document.getElementById("form-success").style.display = "block";</script>';
    } else {
        echo '<script>alert("Sorry, your message could not be sent. Please try again later.");</script>';
    }
}
?>
</body>
</html> 