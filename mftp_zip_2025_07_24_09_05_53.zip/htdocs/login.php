<?php
session_start();

// Database credentials
$servername = "sql109.infinityfree.com";
$dbusername = "if0_39329540";
$dbpassword = "Prem28831924";
$dbname = "if0_39329540_login_db12";

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Wrong username or password';
    } else {
        // Connect to DB
        $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        }
        $stmt = $conn->prepare('SELECT id, password FROM users WHERE username = ?');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 1) {
            $stmt->bind_result($user_id, $hashed_password);
            $stmt->fetch();
            if (!empty($hashed_password) && password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $user_id;
                $_SESSION['username'] = $username;
                header('Location: main.php');
                exit();
            } else {
                $error = 'Wrong username or password';
            }
        } else {
            $error = 'Wrong username or password';
        }
    }
}
?>
<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | CRAVIO</title>
    <link rel="stylesheet" href="style.css">
    <style>
    /* ... existing styles ... */
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <img src="f2-removebg-preview.png" alt="Logo">
            <p>CRAVIO</p>
        </div>
        <form action="login.php" method="POST" class="login-form" autocomplete="off">
            <h2>Login</h2>
            <?php
            if (!empty($error)) {
                echo '<p class="error">' . htmlspecialchars($error) . '</p>';
            }
            if(isset($_GET['success']) && $_GET['success'] == 'registered') {
                echo '<p class="success">Registration successful! Please login.</p>';
            }
            ?>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required autocomplete="username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required autocomplete="current-password">
            </div>
            <button type="submit">Login</button>
            <p class="register-link">Don't have an account? <a href="register.php">Register here</a></p>
        </form>
    </div>
</body>
</html> 