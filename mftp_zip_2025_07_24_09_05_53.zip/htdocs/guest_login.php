<?php
session_start();
// Set guest user session variables
$_SESSION['user_id'] = 'guest';
$_SESSION['username'] = 'Guest';
// Redirect to dashboard or wherever you want
header("Location: dashboard.php");
exit(); 